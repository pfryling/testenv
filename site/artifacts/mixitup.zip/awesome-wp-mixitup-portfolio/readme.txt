=== Plugin Name ===
Donate link: http://nayonbd.com/plugins/?page_id=55
Tags: Awesome wp Mixitup Portfolio,image gallery,photo,widget photo gallery ,awesome photo galley,photo gallery ,mixitup plugin,filter plugin,Mixitup plugin ,isotop plugin,isotop,mixitup,portfolio
Requires at least: 3.0.1
Tested up to: 4.5.3
Stable tag: 4.5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html





Awesome Mixitup Portfolio allows you to create a very modern and outstanding portfolio which filters instantly using jQuery animations. 

== Description ==

Awesome Mixitup Portfolio allows designers, artists, photographers to create, manage and publish a very modern and outstanding Mixitup portfolio that can be filtered using smooth animations and cool image hover effects. Select from a huge set of effects and animation presets to customize the look of your portfolio. Set up, customize and publish your portfolio within just a few minutes.

add shortcode in your page   [advanced-portfolio]


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==


1. This is the first screenshot
2. This is the second screenshot
3. This is the third screenshot


== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

= 0.5 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 0.5 =
This version fixes a security related bug.  Upgrade immediately.

== Arbitrary section ==

You may provide arbitrary sections, in the same format as the ones above.  This may be of use for extremely complicated
plugins where more information needs to be conveyed that doesn't fit into the categories of "description" or
"installation."  Arbitrary sections will be shown below the built-in sections outlined above.

== A brief Markdown Example ==

Ordered list:

1. Some feature
1. Another feature
1. Something else about the plugin

Unordered list:

* something
* something else
* third thing

Here's a link to [WordPress](http://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`
