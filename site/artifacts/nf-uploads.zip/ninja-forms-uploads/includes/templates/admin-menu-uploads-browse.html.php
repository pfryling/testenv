<form method="post">
	<?php
	$table->search_box( __( 'Search Uploads' , 'ninja-forms-uploads' ), 'ninja-forms-uploads' );
	$table->display(); ?>
</form>
