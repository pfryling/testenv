<?php

return array(

    'multi_part' => array(
        'id'       => 'multi_part',
        'nicename' => __( 'Multi-Part', 'ninja-forms-multi-part' ),
    )

);
